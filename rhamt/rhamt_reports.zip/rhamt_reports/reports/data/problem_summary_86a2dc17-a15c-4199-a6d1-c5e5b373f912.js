MIGRATION_ISSUES_DETAILS["86a2dc17-a15c-4199-a6d1-c5e5b373f912"] = [
{description: "<p>Enterprise Java Bean XML Descriptor.<\/p>", ruleID: "DiscoverEjbConfigurationXmlRuleProvider_1", issueName: "EJB XML",
problemSummaryID: "86a2dc17-a15c-4199-a6d1-c5e5b373f912", files: [
{l:"<a class='' href='ejb_jar_xml.html?project=237640'>META-INF/ejb-jar.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("86a2dc17-a15c-4199-a6d1-c5e5b373f912");