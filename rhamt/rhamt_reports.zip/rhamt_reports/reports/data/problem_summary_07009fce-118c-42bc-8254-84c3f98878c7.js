MIGRATION_ISSUES_DETAILS["07009fce-118c-42bc-8254-84c3f98878c7"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "07009fce-118c-42bc-8254-84c3f98878c7", files: [
{l:"<a class='' href='web_xml.html?project=237640'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("07009fce-118c-42bc-8254-84c3f98878c7");