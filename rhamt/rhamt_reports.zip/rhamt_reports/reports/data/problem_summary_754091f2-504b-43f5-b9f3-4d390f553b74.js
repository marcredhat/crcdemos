MIGRATION_ISSUES_DETAILS["754091f2-504b-43f5-b9f3-4d390f553b74"] = [
{description: "<p>The application embeds an Apache Log4J library.<\/p>", ruleID: "logging-usage-00010", issueName: "Embedded library - Apache Log4J",
problemSummaryID: "754091f2-504b-43f5-b9f3-4d390f553b74", files: [
{l:"marc.ear/jee-example-web.war/WEB-INF/lib/log4j-1.2.6.jar", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("754091f2-504b-43f5-b9f3-4d390f553b74");