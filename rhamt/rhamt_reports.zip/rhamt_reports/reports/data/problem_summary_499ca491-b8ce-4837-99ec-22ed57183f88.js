MIGRATION_ISSUES_DETAILS["499ca491-b8ce-4837-99ec-22ed57183f88"] = [
{description: "<p>The application uses Java EE Application Deployment.<\/p>", ruleID: "javaee-technology-usage-00060", issueName: "Java EE Application Deployment",
problemSummaryID: "499ca491-b8ce-4837-99ec-22ed57183f88", files: [
{l:"marc.ear", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("499ca491-b8ce-4837-99ec-22ed57183f88");