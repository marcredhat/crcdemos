MIGRATION_ISSUES_DETAILS["b6f53f7e-6518-4853-b54c-1712894768ef"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "b6f53f7e-6518-4853-b54c-1712894768ef", files: [
{l:"<a class='' href='pom_xml.html?project=237640'>META-INF/maven/org.windup.example/jee-example-app/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.7.html?project=237640'>META-INF/maven/commons-lang/commons-lang/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.13.html?project=237640'>META-INF/maven/org.windup.example/jee-example-services/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.5.html?project=237640'>META-INF/maven/org.migration.support/migration-support/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.3.html?project=237640'>META-INF/maven/org.windup.example/jee-example-web/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("b6f53f7e-6518-4853-b54c-1712894768ef");